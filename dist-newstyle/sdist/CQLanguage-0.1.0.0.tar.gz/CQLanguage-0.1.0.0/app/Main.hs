module Main where

import Lib ()
import CQLTokens
import CQLGrammar
import System.Environment
import Control.Exception
import System.IO
import Data.List

------------------
-- MAIN METHODS --
------------------ 

main :: IO ()
main = catch main' noLex -- catch ==>> {catch <function to try run> <function to run if error occurs>}

main' = do
        (filename : _ ) <- getArgs
        sourceText <- readFile filename
        
        let tokens = alexScanTokens sourceText
        putStrLn ("Lexed as : " ++ (show tokens))
        let exp = parseCalc tokens
        
        result <- eval exp []
        putStrLn (show result)
                                                                                             
                                                
-- eval
        -- @brief:
        -- @params: 
        -- @return:
eval :: Exp -> [(String, [String])] -> IO [String]
eval (LetSel varName selectMethod exp) vars            = evalLetSel varName selectMethod exp vars                                                             
eval (Return returnMethod) vars                        = (evalReturn returnMethod vars)




-----------------
-- LET METHODS -- 
-----------------




-- evalSelect
        -- @brief:
        -- @params: 
        -- @return:
evalLetSel :: String -> SelectMethod -> Exp -> [(String, [String])] -> IO [String]
evalLetSel varName (Read filename) exp vars        = do 
                                                        content <- readFile filename 
                                                        let table = lines content
                                                        eval exp (vars ++ [(varName, table)])
evalLetSel varNameSet (Table varNameFrom) exp vars = do      
                                                        let table = getTable varNameFrom vars
                                                        eval exp (vars ++ [(varNameSet, table)])  
evalLetSel varNameSet selectMethod exp vars        = do      
                                                        let table = evalSelect selectMethod vars
                                                        eval exp (vars ++ [(varNameSet, table)]) 




--------------------
-- SELECT METHODS -- 
--------------------



evalSelect :: SelectMethod -> [(String, [String])] -> [String]
evalSelect (SelectTable varName) vars         = getTable varName vars
evalSelect (SelectTableCol varName cols) vars = selectCols varName cols vars

-- selectCols
        -- @brief:
        -- @params: 
        -- @return:
selectCols :: String -> [Int] -> [(String, [String])] -> [String]
selectCols varName cols vars = do
                                let table = getTable varName vars
                                let tableCols = selectColsAux table cols []
                                return tableCols

selectColsAux:: [String] -> [Int] -> [String]
selectColsAux [] cols         = []
selectColsAux (row:rows) cols = (selectRowCols row cols) : (selectColsAux rows cols)

selectRowCols:: String -> [Int] -> String
selectRowCols row []         = []
selectRowCols row (col:cols) = (cells!!col) : "," ++ (selectRowCols row cols)
        where
                cells = splitOn "," row




----------------------
-- RETURN METHODS -- 
----------------------




-- evalReturn
        -- @brief:
        -- @params: 
        -- @return:
evalReturn :: ReturnMethod -> [(String, [String])] -> IO [String]
evalReturn (ReturnSelect (Table varName)) vars = return (getTable varName vars)
evalReturn (ReturnSelect (SelectTable varName)) vars = return (getTable varName vars)





--------------------
-- HELPER METHODS -- 
--------------------



-- getTable
        -- @brief:
        -- @params: 
        -- @return:
getTable :: String -> [(String, [String])] -> [String]
getTable name []                                           = []
getTable name ((varName, table):vs) | varName == name  = table
                                    | otherwise        = getTable name vs




--------------------
-- ERROR HANDLING --
--------------------




noLex :: ErrorCall -> IO ()
noLex e = do 
             let err =  show e
             hPutStr stderr ("Problem with parsing : " ++ err)
             return ()

-- Gathers all variables from within
-- getVars :: Exp -> IO [(VarCall, [String])] -- list of variables paired with rows
-- getVars (LET varCall (READ filename))           = do 
--                                                         content <- readFile filename 
--                                                         let table = lines content
--                                                         return [(varCall, table)]
-- getVars (Sep (LET varCall (READ filename)) exp) = do   
--                                                          content <- readFile filename  
--                                                          let table = lines content 
--                                                          nextVars <- getVars exp
--                                                          return ([(varCall, table)] ++ nextVars)
-- getVars (Sep exp (LET varCall (READ filename))) = do   
--                                                         content <- readFile filename  
--                                                         let table = lines content 
--                                                         nextVars <- getVars exp
--                                                         return ([(varCall, table)] ++ nextVars)
-- getVars (RETURN returnMethod)                   = return []