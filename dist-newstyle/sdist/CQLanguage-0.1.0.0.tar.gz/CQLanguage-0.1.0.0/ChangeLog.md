# Changelog for CQLanguage

## Unreleased changes
